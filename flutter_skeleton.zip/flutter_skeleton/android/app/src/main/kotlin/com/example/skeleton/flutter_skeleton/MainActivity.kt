package com.example.skeleton.flutter_skeleton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
