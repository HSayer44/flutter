import 'package:bottom_nav_layout/bottom_nav_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_skeleton/src/data/repositories/skeleton_repository.dart';
import 'package:flutter_skeleton/src/feature/login/cubit/login_cubit.dart';
import 'package:flutter_skeleton/src/feature/scan/scan_screen.dart';
import 'package:flutter_skeleton/src/feature/settings/imprint/imprint_screen.dart';
import 'package:flutter_skeleton/src/feature/settings/privacy/privacy_screen.dart';
import 'package:flutter_skeleton/src/feature/settings/settings_screen.dart';

class HomeScreen extends StatelessWidget {
  static const String route = 'home';

  final int initialPage;

  const HomeScreen({super.key, required this.initialPage});

  @override
  Widget build(BuildContext context) {
    return BottomNavLayout(
      pageStack: ReorderToFrontPageStack(initialPage: initialPage),
      pages: [
        (navKey) => Navigator(
              key: navKey,
              initialRoute: '/',
              onGenerateRoute: (routeSettings) => MaterialPageRoute(
                builder: (context) {
                  switch (routeSettings.name) {
                    case '/':
                    default:
                      return BlocProvider<LoginCubit>(
                        create: (context) =>
                            LoginCubit(context.read<SkeletonRepository>()),
                        child: Scaffold(
                          appBar: AppBar(title: const Text('Liste')),
                          body: ListView(
                            children: const [
                              ListTile(
                                title: Text('Listeneintrag'),
                                subtitle: Text('List Element 1'),
                              ),
                              ListTile(
                                title: Text('Listeneintrag'),
                                subtitle: Text('List Element 2'),
                              ),
                              ListTile(
                                title: Text('Listeneintrag'),
                                subtitle: Text('List Element 3'),
                              ),
                            ],
                          ),
                        ),
                      );
                  }
                },
              ),
            ),
        (navKey) => Navigator(
              key: navKey,
              initialRoute: '/',
              onGenerateRoute: (routeSettings) => MaterialPageRoute(
                builder: (context) {
                  switch (routeSettings.name) {
                    case '/':
                    default:
                      return const ScanScreen();
                  }
                },
              ),
            ),
        (navKey) => Navigator(
              key: navKey,
              initialRoute: '/',
              onGenerateRoute: (routeSettings) => MaterialPageRoute(
                builder: (context) {
                  switch (routeSettings.name) {
                    case PrivacyScreen.route:
                      return const PrivacyScreen();
                    case ImprintScreen.route:
                      return const ImprintScreen();
                    case SettingsScreen.route:
                    default:
                      return const SettingsScreen();
                  }
                },
              ),
            ),
      ],
      bottomNavigationBar: (currentIndex, onTap) => NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (index) => onTap(index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.menu),
            label: 'Liste',
          ),
          NavigationDestination(
            icon: Icon(Icons.qr_code_scanner),
            label: 'Scan',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
