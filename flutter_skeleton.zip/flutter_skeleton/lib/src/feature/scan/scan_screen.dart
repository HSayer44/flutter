import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScanScreen extends StatelessWidget {


  const ScanScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR Scanner'),
      ),
      body: Center(
        child: MaterialButton(
          child: const Text('Start Scanner'),
          onPressed: () {
            showDialog<void>(
              context: context,
              builder: (BuildContext context) {
                return ScanDialog();
              },
            );
          },
        ),
      ),
    );
  }
}

class ScanDialog extends StatelessWidget {

  final MobileScannerController cameraController = MobileScannerController();

  ScanDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: SizedBox(
        width: 300,
        height: 500,
        child: MobileScanner(
          controller: cameraController,
          onDetect: (capture) {
            final barcodes = capture.barcodes;
            for (final barcode in barcodes) {
              final code = barcode.rawValue;
              debugPrint('Barcode found! $code');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Barcode read $code'),
                ),
              );
            }
          },
        ),
      ),
      actions: [

        IconButton(
          color: Colors.white,
          icon: ValueListenableBuilder(
            valueListenable: cameraController.torchState,
            builder: (context, state, child) {
              switch (state) {
                case TorchState.off:
                  return const Icon(Icons.flash_off, color: Colors.grey);
                case TorchState.on:
                  return const Icon(Icons.flash_on, color: Colors.white);
              }
            },
          ),
          iconSize: 32,
          onPressed: cameraController.toggleTorch,
        ),
        IconButton(
          color: Colors.white,
          icon: ValueListenableBuilder(
            valueListenable: cameraController.cameraFacingState,
            builder: (context, state, child) {
              switch (state) {
                case CameraFacing.front:
                  return const Icon(Icons.camera_front);
                case CameraFacing.back:
                  return const Icon(Icons.camera_rear);
              }
            },
          ),
          iconSize: 32,
          onPressed: cameraController.switchCamera,
        ),
      ],
    );
  }

}
