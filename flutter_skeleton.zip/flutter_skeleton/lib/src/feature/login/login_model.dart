class LoginModel {
  final String id;
  final String imageUrl;

  LoginModel(this.id, this.imageUrl);
}
