import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_skeleton/src/data/repositories/skeleton_repository.dart';
import 'package:flutter_skeleton/src/feature/login/cubit/login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  final SkeletonRepository repo;

  LoginCubit(this.repo) : super(const LoginState.loading());

  Future<void> login(String mail, String pw) async {
    final result = await repo.login(mail, pw);
    result.when(
      success: (data) {
        emit(LoginState.loaded(data));
      },
      failure: (error) {
        debugPrint('Emit error state and show user facing error');
        emit(LoginState.error(error));
      },
    );
  }
}
