import 'package:flutter_skeleton/src/data/remote/network_exceptions.dart';
import 'package:flutter_skeleton/src/feature/login/login_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'login_state.freezed.dart';

@freezed
class LoginState with _$LoginState {
  const factory LoginState.loading() = Loading;

  const factory LoginState.loaded(LoginModel cat) = Loaded;

  const factory LoginState.error(NetworkException er) = Error;
}
