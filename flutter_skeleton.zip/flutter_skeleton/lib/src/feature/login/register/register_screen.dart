import 'package:flutter/material.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 60),
              child: Center(
                child: SizedBox(
                  width: 150,
                  height: 200,
                  child: Icon(
                    Icons.logo_dev_rounded,
                    color: Theme.of(context).primaryColor,
                    size: 150,
                  ),
                ),
              ),
            ),
            const Padding(
              //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Email',
                  hintText: 'Enter valid email as abc@gmail.com',
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            SizedBox(
              width: 240,
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => Container(),
                    ),
                  );
                },
                child: const Text(
                  'Register',
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
          ],
        ),
      ),
      /*body: BlocBuilder<LoginCubit, LoginState>(
        builder: (context, state) {
          return state.maybeWhen(
            loaded: (cat) {
              return RefreshIndicator(
                onRefresh: () {
                  return context.read<LoginCubit>().login("admin@mintellity.com", "mint2222");
                },
                child: ListView.builder(
                  itemCount: 1,
                  itemBuilder: (context, index) {

                    return ListTile(
                      title: Text("Id: ${cat.id})"),
                      trailing: Image.network(cat.imageUrl),
                    );
                  },
                ),
              );
            },
            orElse: () => const Center(child: CircularProgressIndicator()),
          );
          return Container();
        },
      ),*/
    );
  }
}
