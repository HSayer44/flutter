import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_skeleton/src/feature/login/login_screen.dart';
import 'package:flutter_skeleton/src/feature/settings/imprint/imprint_screen.dart';
import 'package:flutter_skeleton/src/feature/settings/privacy/privacy_screen.dart';
import 'package:package_info_plus/package_info_plus.dart';

class SettingsScreen extends StatelessWidget {
  static const String route = 'settings';

  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Einstellungen'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
                LoginScreen.route,
                (route) => route.settings.name == LoginScreen.route,
              );
            },
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              children: [
                const ListTile(
                  leading: Icon(Icons.notifications),
                  title: Text('Benachrichtigungen'),
                  onTap: AppSettings.openNotificationSettings,
                ),
                ListTile(
                  leading: const Icon(Icons.policy),
                  title: const Text('Datenschutzbestimmungen'),
                  onTap: () {
                    Navigator.of(context).pushNamed(PrivacyScreen.route);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.info),
                  title: const Text('Impressum'),
                  onTap: () {
                    Navigator.of(context).pushNamed(ImprintScreen.route);
                  },
                ),
              ],
            ),
          ),
          const Spacer(),
          FutureBuilder<String>(
            future: getVersion(),
            builder: (context, AsyncSnapshot<String> snapshot) {
              if (snapshot.hasData) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text(
                      snapshot.requireData,
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                  ),
                );
              } else {
                return const CircularProgressIndicator();
              }
            },
          )
        ],
      ),
    );
  }

  Future<String> getVersion() async {
    final packageInfo = await PackageInfo.fromPlatform();

    final appName = packageInfo.appName;
    final version = packageInfo.version;
    final buildNumber = packageInfo.buildNumber;

    return '$appName $version ($buildNumber)';
  }
}
