import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_skeleton/generated/l10n.dart';
import 'package:flutter_skeleton/src/data/local/local_repository.dart';
import 'package:flutter_skeleton/src/data/remote/remote_repository.dart';
import 'package:flutter_skeleton/src/data/repositories/skeleton_repository.dart';
import 'package:flutter_skeleton/src/feature/home/home_screen.dart';
import 'package:flutter_skeleton/src/feature/login/cubit/login_cubit.dart';
import 'package:flutter_skeleton/src/feature/login/login_screen.dart';
import 'package:flutter_skeleton/src/util/skeleton_theme.dart';

final globalNavKey = GlobalKey<NavigatorState>();

class SkeletonApp extends StatelessWidget {
  final LocalRepository localRepo;
  final RemoteRepository remoteRepo;

  const SkeletonApp({
    super.key,
    required this.localRepo,
    required this.remoteRepo,
  });

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider(
          create: (context) => SkeletonRepository(localRepo, remoteRepo),
        )
      ],
      child: MaterialApp(
        localizationsDelegates: const [
          S.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate
        ],
        title: 'Flutter Demo',
        navigatorKey: globalNavKey,
        theme: lightTheme,
        darkTheme: darkTheme,
        initialRoute:
            localRepo.isLoggedIn() ? HomeScreen.route : LoginScreen.route,
        onGenerateRoute: (settings) {
          return MaterialPageRoute(
            builder: (context) {
              switch (settings.name) {
                case HomeScreen.route:
                  return const HomeScreen(initialPage: 0);
                default:
                  return BlocProvider<LoginCubit>(
                    create: (context) =>
                        LoginCubit(context.read<SkeletonRepository>()),
                    child: const LoginScreen(),
                  );
              }
            },
          );
        },
      ),
    );
  }
}
