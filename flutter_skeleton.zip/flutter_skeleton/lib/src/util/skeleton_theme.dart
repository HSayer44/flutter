import 'package:flutter/material.dart';

const primaryColor = Color.fromARGB(255, 79, 187, 61); // #4FBB3D

final colorSchemeLight = ColorScheme.fromSeed(seedColor: primaryColor);

final colorSchemeDark = ColorScheme.fromSeed(
  brightness: Brightness.dark,
  seedColor: primaryColor,
);

final lightTheme = ThemeData(
  primaryColor: primaryColor,
  colorScheme: colorSchemeLight,
  elevatedButtonTheme: const ElevatedButtonThemeData(
    style: ButtonStyle(backgroundColor: MaterialStatePropertyAll(primaryColor)),
  ),
  useMaterial3: true,
);

final darkTheme = ThemeData(
  primaryColor: primaryColor,
  colorScheme: colorSchemeDark,
  useMaterial3: true,
);
