import 'package:flutter_skeleton/src/data/local/database/skeleton_database.dart';

// ignore_for_file: unused_field
class LocalRepository {
  final SkeletonDatabase _db;

  LocalRepository(this._db);


  // TODO(aljlue): couple this with Hive / SharedPreferences
  bool isLoggedIn() {
    return false;
  }
}
