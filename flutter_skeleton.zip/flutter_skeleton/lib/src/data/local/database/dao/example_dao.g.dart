// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'example_dao.dart';

// ignore_for_file: type=lint
mixin _$ExampleDaoMixin on DatabaseAccessor<SkeletonDatabase> {
  $ExampleTable get example => attachedDatabase.example;
}
