import 'package:flutter_skeleton/src/data/local/local_repository.dart';
import 'package:flutter_skeleton/src/data/remote/api_result.dart';
import 'package:flutter_skeleton/src/data/remote/remote_repository.dart';
import 'package:flutter_skeleton/src/feature/login/login_model.dart';

// ignore_for_file: unused_field
class SkeletonRepository {
  final RemoteRepository _remoteRepo;
  final LocalRepository _localRepo;

  SkeletonRepository(this._localRepo, this._remoteRepo);

  Future<ApiResult<LoginModel>> login(String mail, String pw) async {
    final response = await _remoteRepo.login(mail, pw);
    return response.when(
      success: (data) {
        return ApiResult.success(
          LoginModel(data.appToken, data.appToken),
        );
      },
      failure: (error) {
        return ApiResult.failure(error: error);
      },
    );
  }
}
