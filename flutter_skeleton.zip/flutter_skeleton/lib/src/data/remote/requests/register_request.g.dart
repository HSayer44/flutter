// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegisterRequest _$RegisterRequestFromJson(Map<String, dynamic> json) =>
    RegisterRequest(
      mail: json['email'] as String?,
      pw: json['password'] as String?,
      pwConfirm: json['password_confirmation'] as String?,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$RegisterRequestToJson(RegisterRequest instance) =>
    <String, dynamic>{
      'email': instance.mail,
      'password': instance.pw,
      'password_confirmation': instance.pwConfirm,
      'name': instance.name,
    };
