import 'package:json_annotation/json_annotation.dart';

part 'login_request.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake, explicitToJson: true)
class LoginRequest {
  @JsonKey(name: 'email')
  final String? mail;
  @JsonKey(name: 'password')
  final String? pw;

  LoginRequest({
    this.mail,
    this.pw,
  });

  factory LoginRequest.fromJson(Map<String, dynamic> json) {
    return _$LoginRequestFromJson(json);
  }

  Map<String, dynamic> toJson() => _$LoginRequestToJson(this);
}
