import 'package:json_annotation/json_annotation.dart';

part 'forgot_request.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake, explicitToJson: true)
class ForgotRequest {
  @JsonKey(name: 'email')
  final String? mail;

  ForgotRequest({
    this.mail,
  });

  factory ForgotRequest.fromJson(Map<String, dynamic> json) {
    return _$ForgotRequestFromJson(json);
  }

  Map<String, dynamic> toJson() => _$ForgotRequestToJson(this);
}
