import 'package:json_annotation/json_annotation.dart';

part 'register_request.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake, explicitToJson: true)
class RegisterRequest {
  @JsonKey(name: 'email')
  final String? mail;
  @JsonKey(name: 'password')
  final String? pw;
  @JsonKey(name: 'password_confirmation')
  final String? pwConfirm;
  final String? name;

  RegisterRequest({
    this.mail,
    this.pw,
    this.pwConfirm,
    this.name,
  });

  factory RegisterRequest.fromJson(Map<String, dynamic> json) {
    return _$RegisterRequestFromJson(json);
  }

  Map<String, dynamic> toJson() => _$RegisterRequestToJson(this);
}
