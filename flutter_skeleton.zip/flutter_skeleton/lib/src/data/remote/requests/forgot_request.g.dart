// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'forgot_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ForgotRequest _$ForgotRequestFromJson(Map<String, dynamic> json) =>
    ForgotRequest(
      mail: json['email'] as String?,
    );

Map<String, dynamic> _$ForgotRequestToJson(ForgotRequest instance) =>
    <String, dynamic>{
      'email': instance.mail,
    };
