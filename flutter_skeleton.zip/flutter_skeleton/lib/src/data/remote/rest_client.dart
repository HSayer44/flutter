import 'package:dio/dio.dart';
import 'package:flutter_skeleton/src/data/remote/requests/forgot_request.dart';
import 'package:flutter_skeleton/src/data/remote/requests/login_request.dart';
import 'package:flutter_skeleton/src/data/remote/requests/register_request.dart';
import 'package:flutter_skeleton/src/data/remote/responses/login_response.dart';
import 'package:retrofit/retrofit.dart';

part 'rest_client.g.dart';

@RestApi()
abstract class RestClient {
  factory RestClient(Dio dio, {String baseUrl}) = _RestClient;

  @POST('/login')
  Future<LoginResponse> login(@Body() LoginRequest request);

  @POST('/register')
  Future<LoginResponse> register(RegisterRequest request);

  @POST('/forgot')
  Future<dynamic> forgot(ForgotRequest request);
}
