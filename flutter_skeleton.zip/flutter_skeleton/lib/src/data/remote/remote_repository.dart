import 'package:dio/dio.dart';
import 'package:flutter_skeleton/src/data/remote/api_result.dart';
import 'package:flutter_skeleton/src/data/remote/network_exceptions.dart';
import 'package:flutter_skeleton/src/data/remote/requests/login_request.dart';
import 'package:flutter_skeleton/src/data/remote/responses/login_response.dart';
import 'package:flutter_skeleton/src/data/remote/rest_client.dart';

const String testApiUrl = 'https://app-auth.mintellity.dev/api/v1/';
const String liveApiUrl = '';

class RemoteRepository {
  final Dio _dio = Dio();
  final String apiKey;
  late RestClient _restClient;

  RemoteRepository({required this.apiKey, bool isDev = false}) {
    _dio.options.baseUrl = isDev ? testApiUrl : liveApiUrl;
    _dio.options.headers['x-api-key'] = apiKey;

    if (isDev) {
      // Example for basic auth
      _dio.options.headers['authorization'] = 'Basic cXVpeDptaW50MjIyMg==';

      _dio.interceptors.add(
        LogInterceptor(
          requestBody: true,
          responseBody: true,
        ),
      );
    }
    _restClient = RestClient(_dio, baseUrl: isDev ? testApiUrl : liveApiUrl);
  }

  void addSessionHeader(String sessionToken) {
    _dio.options.headers['session-token'] = sessionToken;
  }

  void removeSessionHeader() {
    _dio.options.headers.remove('session-token');
  }

  Future<ApiResult<LoginResponse>> login(
    String mail,
    String pw,
  ) async {
    final request = LoginRequest(mail: mail, pw: pw);
    try {
      final response = await _restClient.login(request);

      return ApiResult.success(response);
    } catch (e) {
      return ApiResult.failure(error: NetworkException.fromError(e));
    }
  }
}
